<!DOCTYPE html>
<html>



<head>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, inital-scale1.0">
    <div class="container-fluid p-5 bg-primary text-white text-center">
        
</head>

<body>
    <div class="container-fluid p-5 bg-primary text-white text-center">
        
    <div class="container-fluid mt-3">
        <h1>ประวัติส่วนตัว</h1>
        <p>จัดทำเพื่อแนะนำเสนอประวัติตัวเองในรูปแบบเว็บไซต์</p>
        <div class="row">
            <a class="menu" href="C:\xampp\htdocs\test d5\frank5520\index.html">หน้าหลัก</a>
            <div class="col p-3 bg-dark text-white">.col</div>
            <div class="col p-3 bg-dark text-white">.col</div>
            <div class="col p-3 bg-dark text-white">.col</div>
        </div>
    </div>

    <div class="container-fluid p-5 bg-primary text-white text-center">

        <div class="container mt-5">
            <div class="row">
              <div class="col-sm-4">
                <h3>Column 1</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
              </div>
              <div class="col-sm-4">
                <h3>Column 2</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
              </div>
              <div class="col-sm-4">
                <h3>Column 3</h3>        
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
              </div>
            </div>
          </div>

        <body>



            <h1 style="color:rgb(28, 71, 180);">ประวัติส่วนตัว</h1>
            </style>
            <img src="f2.jpg" alt="Trulli" width="300" height="250">
            <h2 style="color:rgb(180, 76, 28);">ชื่อ นาย รัฐศาสตร์ สิงห์วงศ์</h2>
            <h2 style="color:rgb(180, 76, 28);">ชื่อเล่น แฟรงค์</h2>
            <h2 style="color:rgb(180, 76, 28);">อายุ 18 ปี</h2>
            <h2 style="color:rgb(180, 76, 28);">กรุ๊ปเลือด O</h2>
            <h2 style="color:rgb(180, 76, 28);">ที่อยู่</h2>
            <h3 style="color:rgb(22, 236, 211);">195 บ.หนองคู ต.กุดตุ้ม อ.เมือง.จังหวัดชัยภูมิ
                36000
            </h3>
            <h2 style="color:rgb(180, 76, 28);">วันเดือนปีเกิด</h2>
            <h3 style="color:rgb(22, 236, 211);">13 มกราคม พ.ศ.2549</h3>
            <h1 style="color:rgb(28, 71, 180);">เกี่ยวกับฉัน</h1>
            <h2 style="color:rgb(22, 236, 211);">เด็กหนุ่มร่างใหญ่เหมือนหมี คุยได้ไม่ต้องกลัว คุยกันได้ทุกเรื่องนั้นแหละ
                ยินดีที่ได้รู้จักน่ะ</h2>
            <h2></h2>
            <h1 style="color:rgb(28, 71, 180);">
                </h2style>ช่องทางการติดต่อ</h1>
            <h2 style="color:rgb(180, 76, 28);">line 0652367535</h2>
            <h2 style="color:rgb(180, 76, 28);">Facebook rattasat singwong</h2>
            <h2 style="color:rgb(180, 76, 28);">phon number 0652367535
            </h2>
            <h2 style="color:rgb(180, 76, 28);">gmail loona8058@gmail.com</h2>
            <h1 style="color:rgb(28, 71, 180);">ข้อมูลส่วนตัว</h1>
            <h2 style="color:rgb(22, 236, 211);">ชื่อบิดา:นาย เกรียงศักดิ์ สิงห์วงศ์ อายุ50ปี
                อาชีพ:ค้าขาย เบอร์โทรศัพท์ 0810690639

                <h2 style="color:rgb(22, 236, 211);"> ชื่อมารดา:นางสาว รัฐพร อาจโนนเปลือย อายุ37ปี
                    อาชีพ:ค้าขาย เบอร์โทรศัพท์ - </h2>
            </h2>
            <h2 style="color:rgb(180, 76, 28);">ประวัติการศึกษา</h2>
            <h3 style="color:rgb(22, 236, 211);">เคยศึกษาระดับชั้นประถมศึกษาอยู่ที่ โรงเรียนสุนทรวัฒนา
                เคยศึกษาระดับชั้นมัธยมศึกษาอยู่ที่ โรงเรียนเมืองพญาแลวิทยา
            </h3>
            <h2 style="color:rgb(180, 76, 28);">คติประจำใจ</h2>
            <h3 style="color:rgb(22, 236, 211);">บางครั้งก็ต้องหัดเห็นแก่ตัวบ้าง</h3>
            <h2 style="color:rgb(180, 76, 28);">งานอดิเรก</h2>
            <h3 style="color:rgb(22, 236, 211);">ฟังเพลง เล่นเกม วาดรูป เล่น tiktok</h3>
            <h1 style="color:rgb(28, 71, 180);">นักศึกษาเลือกสาขานี้เพราะอะไร เรียนจบอยากทำอาชีพอะไร?</h1>
            <h3 style="color:rgb(22, 236, 211);">เพราะมีความต้องการที่จะเรียนเกี่ยวกับการเขียนโค้ดและพัฒนาโปรแกรมต่างๆ
                เรียนจบอยากเป็นนักออกแบบและตัดต่อวิดีโอกราฟิกอนิเมชั่น</h3>
            <p style="color:rgb(22, 236, 211);">ขอบคุณครับ</p>

        </body>

</html>